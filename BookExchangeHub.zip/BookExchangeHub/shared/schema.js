import { pgTable, text, serial, integer, decimal, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

export const books = pgTable("books", {
  id: serial("id").primaryKey(),
  isbn: text("isbn").unique(),
  title: text("title").notNull(),
  author: text("author"),
  publisher: text("publisher"),
  publishedYear: integer("published_year"),
  genre: text("genre"),
  condition: text("condition"),
  description: text("description"),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const inventory = pgTable("inventory", {
  id: serial("id").primaryKey(),
  bookId: integer("book_id").references(() => books.id).notNull(),
  quantity: integer("quantity").notNull().default(0),
  location: text("location"),
  status: text("status").notNull().default("available"),
  acquisitionDate: timestamp("acquisition_date").defaultNow(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const pricing = pgTable("pricing", {
  id: serial("id").primaryKey(),
  bookId: integer("book_id").references(() => books.id).notNull(),
  ourPrice: decimal("our_price", { precision: 10, scale: 2 }),
  marketValue: decimal("market_value", { precision: 10, scale: 2 }),
  creditValue: decimal("credit_value", { precision: 10, scale: 2 }),
  costBasis: decimal("cost_basis", { precision: 10, scale: 2 }),
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").unique(),
  phone: text("phone"),
  creditBalance: decimal("credit_balance", { precision: 10, scale: 2 }).default("0"),
  totalPurchases: decimal("total_purchases", { precision: 10, scale: 2 }).default("0"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").references(() => customers.id),
  transactionType: text("transaction_type").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  creditUsed: decimal("credit_used", { precision: 10, scale: 2 }).default("0"),
  creditEarned: decimal("credit_earned", { precision: 10, scale: 2 }).default("0"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const transactionItems = pgTable("transaction_items", {
  id: serial("id").primaryKey(),
  transactionId: integer("transaction_id").references(() => transactions.id).notNull(),
  bookId: integer("book_id").references(() => books.id).notNull(),
  quantity: integer("quantity").notNull().default(1),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const marketplaceListings = pgTable("marketplace_listings", {
  id: serial("id").primaryKey(),
  bookId: integer("book_id").references(() => books.id).notNull(),
  marketplace: text("marketplace").notNull(),
  listingId: text("listing_id"),
  listingUrl: text("listing_url"),
  price: decimal("price", { precision: 10, scale: 2 }),
  status: text("status").notNull().default("active"),
  isActive: boolean("is_active").default(true),
  metadata: jsonb("metadata"),
  lastSynced: timestamp("last_synced"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const booksRelations = relations(books, ({ many, one }) => ({
  inventory: many(inventory),
  pricing: one(pricing),
  marketplaceListings: many(marketplaceListings),
  transactionItems: many(transactionItems),
}));

export const inventoryRelations = relations(inventory, ({ one }) => ({
  book: one(books, {
    fields: [inventory.bookId],
    references: [books.id],
  }),
}));

export const pricingRelations = relations(pricing, ({ one }) => ({
  book: one(books, {
    fields: [pricing.bookId],
    references: [books.id],
  }),
}));

export const customersRelations = relations(customers, ({ many }) => ({
  transactions: many(transactions),
}));

export const transactionsRelations = relations(transactions, ({ one, many }) => ({
  customer: one(customers, {
    fields: [transactions.customerId],
    references: [customers.id],
  }),
  items: many(transactionItems),
}));

export const transactionItemsRelations = relations(transactionItems, ({ one }) => ({
  transaction: one(transactions, {
    fields: [transactionItems.transactionId],
    references: [transactions.id],
  }),
  book: one(books, {
    fields: [transactionItems.bookId],
    references: [books.id],
  }),
}));

export const marketplaceListingsRelations = relations(marketplaceListings, ({ one }) => ({
  book: one(books, {
    fields: [marketplaceListings.bookId],
    references: [books.id],
  }),
}));
