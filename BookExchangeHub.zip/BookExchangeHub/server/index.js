import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from 'ws';
import { eq, desc, like, sql } from 'drizzle-orm';
import * as schema from '../shared/schema.js';
import axios from 'axios';

dotenv.config();

neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL must be set');
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle({ client: pool, schema });

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

app.get('/api/books', async (req, res) => {
  try {
    const { search, genre, condition } = req.query;
    let query = db.select({
      book: schema.books,
      inventory: schema.inventory,
      pricing: schema.pricing,
    })
    .from(schema.books)
    .leftJoin(schema.inventory, eq(schema.books.id, schema.inventory.bookId))
    .leftJoin(schema.pricing, eq(schema.books.id, schema.pricing.bookId));

    const results = await query;
    
    let filteredResults = results;
    if (search) {
      const searchLower = search.toLowerCase();
      filteredResults = filteredResults.filter(r => 
        r.book.title?.toLowerCase().includes(searchLower) ||
        r.book.author?.toLowerCase().includes(searchLower) ||
        r.book.isbn?.toLowerCase().includes(searchLower)
      );
    }
    if (genre) {
      filteredResults = filteredResults.filter(r => r.book.genre === genre);
    }
    if (condition) {
      filteredResults = filteredResults.filter(r => r.book.condition === condition);
    }

    res.json(filteredResults);
  } catch (error) {
    console.error('Error fetching books:', error);
    res.status(500).json({ error: 'Failed to fetch books' });
  }
});

app.get('/api/books/:id', async (req, res) => {
  try {
    const bookId = parseInt(req.params.id);
    const result = await db.select({
      book: schema.books,
      inventory: schema.inventory,
      pricing: schema.pricing,
    })
    .from(schema.books)
    .leftJoin(schema.inventory, eq(schema.books.id, schema.inventory.bookId))
    .leftJoin(schema.pricing, eq(schema.books.id, schema.pricing.bookId))
    .where(eq(schema.books.id, bookId));

    if (result.length === 0) {
      return res.status(404).json({ error: 'Book not found' });
    }

    const listings = await db.select()
      .from(schema.marketplaceListings)
      .where(eq(schema.marketplaceListings.bookId, bookId));

    res.json({ ...result[0], marketplaceListings: listings });
  } catch (error) {
    console.error('Error fetching book:', error);
    res.status(500).json({ error: 'Failed to fetch book' });
  }
});

app.post('/api/books', async (req, res) => {
  try {
    const bookData = req.body;
    
    const [book] = await db.insert(schema.books).values({
      isbn: bookData.isbn,
      title: bookData.title,
      author: bookData.author,
      publisher: bookData.publisher,
      publishedYear: bookData.publishedYear,
      genre: bookData.genre,
      condition: bookData.condition,
      description: bookData.description,
      imageUrl: bookData.imageUrl,
    }).returning();

    if (bookData.quantity !== undefined) {
      await db.insert(schema.inventory).values({
        bookId: book.id,
        quantity: bookData.quantity || 0,
        location: bookData.location || '',
        status: 'available',
      });
    }

    if (bookData.ourPrice !== undefined || bookData.marketValue !== undefined || bookData.creditValue !== undefined) {
      await db.insert(schema.pricing).values({
        bookId: book.id,
        ourPrice: bookData.ourPrice ?? '0',
        marketValue: bookData.marketValue ?? '0',
        creditValue: bookData.creditValue ?? '0',
        costBasis: bookData.costBasis ?? '0',
      });
    }

    res.status(201).json(book);
  } catch (error) {
    console.error('Error creating book:', error);
    res.status(500).json({ error: 'Failed to create book' });
  }
});

app.put('/api/books/:id', async (req, res) => {
  try {
    const bookId = parseInt(req.params.id);
    const bookData = req.body;
    
    const [updatedBook] = await db.update(schema.books)
      .set({
        ...bookData,
        updatedAt: new Date(),
      })
      .where(eq(schema.books.id, bookId))
      .returning();

    if (!updatedBook) {
      return res.status(404).json({ error: 'Book not found' });
    }

    res.json(updatedBook);
  } catch (error) {
    console.error('Error updating book:', error);
    res.status(500).json({ error: 'Failed to update book' });
  }
});

app.delete('/api/books/:id', async (req, res) => {
  try {
    const bookId = parseInt(req.params.id);
    
    const transactionHistory = await db.select()
      .from(schema.transactionItems)
      .where(eq(schema.transactionItems.bookId, bookId))
      .limit(1);

    if (transactionHistory.length > 0) {
      return res.status(409).json({ 
        error: 'Cannot delete book with transaction history. Please archive instead.' 
      });
    }
    
    await db.delete(schema.inventory).where(eq(schema.inventory.bookId, bookId));
    await db.delete(schema.pricing).where(eq(schema.pricing.bookId, bookId));
    await db.delete(schema.marketplaceListings).where(eq(schema.marketplaceListings.bookId, bookId));
    await db.delete(schema.books).where(eq(schema.books.id, bookId));

    res.json({ message: 'Book deleted successfully' });
  } catch (error) {
    console.error('Error deleting book:', error);
    res.status(500).json({ error: 'Failed to delete book' });
  }
});

app.put('/api/inventory/:id', async (req, res) => {
  try {
    const inventoryId = parseInt(req.params.id);
    const { quantity, location, status } = req.body;
    
    if (quantity !== undefined && quantity < 0) {
      return res.status(400).json({ error: 'Quantity cannot be negative' });
    }
    
    const [updated] = await db.update(schema.inventory)
      .set({ quantity, location, status, updatedAt: new Date() })
      .where(eq(schema.inventory.id, inventoryId))
      .returning();

    res.json(updated);
  } catch (error) {
    console.error('Error updating inventory:', error);
    res.status(500).json({ error: 'Failed to update inventory' });
  }
});

app.put('/api/pricing/:bookId', async (req, res) => {
  try {
    const bookId = parseInt(req.params.bookId);
    const { ourPrice, marketValue, creditValue, costBasis } = req.body;
    
    const existing = await db.select()
      .from(schema.pricing)
      .where(eq(schema.pricing.bookId, bookId));

    let result;
    if (existing.length === 0) {
      [result] = await db.insert(schema.pricing).values({
        bookId,
        ourPrice,
        marketValue,
        creditValue,
        costBasis,
      }).returning();
    } else {
      [result] = await db.update(schema.pricing)
        .set({ ourPrice, marketValue, creditValue, costBasis, lastUpdated: new Date() })
        .where(eq(schema.pricing.bookId, bookId))
        .returning();
    }

    res.json(result);
  } catch (error) {
    console.error('Error updating pricing:', error);
    res.status(500).json({ error: 'Failed to update pricing' });
  }
});

app.get('/api/customers', async (req, res) => {
  try {
    const customers = await db.select().from(schema.customers).orderBy(desc(schema.customers.createdAt));
    res.json(customers);
  } catch (error) {
    console.error('Error fetching customers:', error);
    res.status(500).json({ error: 'Failed to fetch customers' });
  }
});

app.post('/api/customers', async (req, res) => {
  try {
    const [customer] = await db.insert(schema.customers)
      .values(req.body)
      .returning();
    res.status(201).json(customer);
  } catch (error) {
    console.error('Error creating customer:', error);
    res.status(500).json({ error: 'Failed to create customer' });
  }
});

app.post('/api/customers/import', async (req, res) => {
  try {
    const { customers } = req.body;
    
    if (!customers || !Array.isArray(customers)) {
      return res.status(400).json({ error: 'Invalid import data' });
    }

    const results = {
      imported: 0,
      skipped: 0,
      errors: []
    };

    for (const customerData of customers) {
      try {
        if (!customerData.name || customerData.name.trim() === '') {
          results.skipped++;
          results.errors.push({ row: customerData, error: 'Name is required' });
          continue;
        }

        const creditBalance = customerData.creditBalance || customerData.credit || customerData.storeCredit || '0';
        
        await db.insert(schema.customers).values({
          name: customerData.name.trim(),
          email: customerData.email?.trim() || null,
          phone: customerData.phone?.trim() || null,
          creditBalance: String(creditBalance),
          totalPurchases: '0',
        });
        
        results.imported++;
      } catch (error) {
        results.skipped++;
        results.errors.push({ 
          row: customerData, 
          error: error.message 
        });
      }
    }

    res.json(results);
  } catch (error) {
    console.error('Error importing customers:', error);
    res.status(500).json({ error: 'Failed to import customers' });
  }
});

app.get('/api/transactions', async (req, res) => {
  try {
    const transactions = await db.select({
      transaction: schema.transactions,
      customer: schema.customers,
    })
    .from(schema.transactions)
    .leftJoin(schema.customers, eq(schema.transactions.customerId, schema.customers.id))
    .orderBy(desc(schema.transactions.createdAt));

    res.json(transactions);
  } catch (error) {
    console.error('Error fetching transactions:', error);
    res.status(500).json({ error: 'Failed to fetch transactions' });
  }
});

app.post('/api/transactions', async (req, res) => {
  try {
    const { customerId, transactionType, amount, creditUsed, creditEarned, notes, items } = req.body;
    
    const [transaction] = await db.insert(schema.transactions)
      .values({
        customerId,
        transactionType,
        amount,
        creditUsed: creditUsed || '0',
        creditEarned: creditEarned || '0',
        notes,
      })
      .returning();

    if (items && items.length > 0) {
      for (const item of items) {
        await db.insert(schema.transactionItems).values({
          transactionId: transaction.id,
          bookId: item.bookId,
          quantity: item.quantity,
          price: item.price,
        });

        const [currentInventory] = await db.select()
          .from(schema.inventory)
          .where(eq(schema.inventory.bookId, item.bookId));

        if (currentInventory) {
          const newQuantity = transactionType === 'purchase' || transactionType === 'trade-in'
            ? currentInventory.quantity + item.quantity
            : currentInventory.quantity - item.quantity;

          await db.update(schema.inventory)
            .set({ quantity: newQuantity, updatedAt: new Date() })
            .where(eq(schema.inventory.bookId, item.bookId));
        }
      }
    }

    if (customerId) {
      const [customer] = await db.select()
        .from(schema.customers)
        .where(eq(schema.customers.id, customerId));

      if (customer) {
        const newCreditBalance = parseFloat(customer.creditBalance || '0') - parseFloat(creditUsed || '0') + parseFloat(creditEarned || '0');
        const newTotalPurchases = parseFloat(customer.totalPurchases || '0') + parseFloat(amount || '0');

        await db.update(schema.customers)
          .set({
            creditBalance: newCreditBalance.toFixed(2),
            totalPurchases: newTotalPurchases.toFixed(2),
            updatedAt: new Date(),
          })
          .where(eq(schema.customers.id, customerId));
      }
    }

    res.status(201).json(transaction);
  } catch (error) {
    console.error('Error creating transaction:', error);
    res.status(500).json({ error: 'Failed to create transaction' });
  }
});

app.get('/api/marketplace-listings', async (req, res) => {
  try {
    const listings = await db.select({
      listing: schema.marketplaceListings,
      book: schema.books,
    })
    .from(schema.marketplaceListings)
    .leftJoin(schema.books, eq(schema.marketplaceListings.bookId, schema.books.id))
    .orderBy(desc(schema.marketplaceListings.createdAt));

    res.json(listings);
  } catch (error) {
    console.error('Error fetching marketplace listings:', error);
    res.status(500).json({ error: 'Failed to fetch marketplace listings' });
  }
});

app.post('/api/marketplace-listings', async (req, res) => {
  try {
    const [listing] = await db.insert(schema.marketplaceListings)
      .values(req.body)
      .returning();
    res.status(201).json(listing);
  } catch (error) {
    console.error('Error creating marketplace listing:', error);
    res.status(500).json({ error: 'Failed to create marketplace listing' });
  }
});

app.put('/api/marketplace-listings/:id', async (req, res) => {
  try {
    const listingId = parseInt(req.params.id);
    const [updated] = await db.update(schema.marketplaceListings)
      .set({ ...req.body, updatedAt: new Date() })
      .where(eq(schema.marketplaceListings.id, listingId))
      .returning();

    res.json(updated);
  } catch (error) {
    console.error('Error updating marketplace listing:', error);
    res.status(500).json({ error: 'Failed to update marketplace listing' });
  }
});

app.get('/api/stats', async (req, res) => {
  try {
    const totalBooks = await db.select({ count: sql`count(*)` }).from(schema.books);
    const totalInventory = await db.select({ total: sql`sum(quantity)` }).from(schema.inventory);
    const totalCustomers = await db.select({ count: sql`count(*)` }).from(schema.customers);
    const recentTransactions = await db.select().from(schema.transactions).orderBy(desc(schema.transactions.createdAt)).limit(5);

    res.json({
      totalBooks: parseInt(totalBooks[0].count),
      totalInventory: parseInt(totalInventory[0].total || '0'),
      totalCustomers: parseInt(totalCustomers[0].count),
      recentTransactions,
    });
  } catch (error) {
    console.error('Error fetching stats:', error);
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Book Exchange Server running on port ${PORT}`);
});
