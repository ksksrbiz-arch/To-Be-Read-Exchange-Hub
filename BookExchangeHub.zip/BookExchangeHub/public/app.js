const API_URL = window.location.origin;

let currentSection = 'dashboard';
let booksData = [];
let customersData = [];
let transactionsData = [];
let listingsData = [];

document.addEventListener('DOMContentLoaded', () => {
    initializeNavigation();
    loadDashboard();
    setupSearchFilters();
});

function initializeNavigation() {
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const section = e.target.dataset.section;
            switchSection(section);
        });
    });
}

function switchSection(section) {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    
    document.getElementById(section).classList.add('active');
    document.querySelector(`[data-section="${section}"]`).classList.add('active');
    
    currentSection = section;
    
    switch(section) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'books':
            loadBooks();
            break;
        case 'customers':
            loadCustomers();
            break;
        case 'transactions':
            loadTransactions();
            break;
        case 'marketplaces':
            loadMarketplaceListings();
            break;
    }
}

async function loadDashboard() {
    try {
        const response = await fetch(`${API_URL}/api/stats`);
        const stats = await response.json();
        
        document.getElementById('stat-books').textContent = stats.totalBooks;
        document.getElementById('stat-inventory').textContent = stats.totalInventory;
        document.getElementById('stat-customers').textContent = stats.totalCustomers;
        document.getElementById('stat-transactions').textContent = stats.recentTransactions.length;
        
        const recentList = document.getElementById('recent-transactions-list');
        recentList.innerHTML = stats.recentTransactions.map(t => `
            <div class="transaction-item">
                <div>
                    <strong>${t.transactionType}</strong>
                    <p style="font-size: 12px; color: #666;">${new Date(t.createdAt).toLocaleString()}</p>
                </div>
                <div style="text-align: right;">
                    <strong>$${parseFloat(t.amount).toFixed(2)}</strong>
                    ${t.creditUsed > 0 ? `<p style="font-size: 12px; color: #666;">Credit: $${parseFloat(t.creditUsed).toFixed(2)}</p>` : ''}
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

async function loadBooks(filters = {}) {
    try {
        const params = new URLSearchParams(filters);
        const response = await fetch(`${API_URL}/api/books?${params}`);
        booksData = await response.json();
        renderBooks(booksData);
    } catch (error) {
        console.error('Error loading books:', error);
    }
}

function renderBooks(books) {
    const container = document.getElementById('books-list');
    
    if (books.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 40px; color: #666;">No books found. Add your first book to get started!</p>';
        return;
    }
    
    container.innerHTML = books.map(item => {
        const book = item.book;
        const inventory = item.inventory;
        const pricing = item.pricing;
        
        return `
            <div class="book-card">
                <h3>${book.title || 'Untitled'}</h3>
                <p><strong>Author:</strong> ${book.author || 'Unknown'}</p>
                ${book.isbn ? `<p><strong>ISBN:</strong> ${book.isbn}</p>` : ''}
                ${book.genre ? `<p><strong>Genre:</strong> ${book.genre}</p>` : ''}
                ${book.condition ? `<p><strong>Condition:</strong> ${book.condition}</p>` : ''}
                ${inventory ? `<p><strong>Quantity:</strong> ${inventory.quantity}</p>` : ''}
                ${pricing ? `<div class="price">$${parseFloat(pricing.ourPrice || 0).toFixed(2)}</div>` : ''}
                ${pricing ? `<p style="font-size: 12px; color: #666;">Market Value: $${parseFloat(pricing.marketValue || 0).toFixed(2)}</p>` : ''}
                ${pricing ? `<p style="font-size: 12px; color: #666;">Credit Value: $${parseFloat(pricing.creditValue || 0).toFixed(2)}</p>` : ''}
                <div class="actions">
                    <button class="btn-success" onclick="editBook(${book.id})">Edit</button>
                    <button class="btn-danger" onclick="deleteBook(${book.id})">Delete</button>
                </div>
            </div>
        `;
    }).join('');
}

function setupSearchFilters() {
    const searchInput = document.getElementById('search-books');
    const genreFilter = document.getElementById('filter-genre');
    const conditionFilter = document.getElementById('filter-condition');
    
    const applyFilters = () => {
        const filters = {};
        if (searchInput.value) filters.search = searchInput.value;
        if (genreFilter.value) filters.genre = genreFilter.value;
        if (conditionFilter.value) filters.condition = conditionFilter.value;
        loadBooks(filters);
    };
    
    searchInput.addEventListener('input', applyFilters);
    genreFilter.addEventListener('change', applyFilters);
    conditionFilter.addEventListener('change', applyFilters);
}

async function loadCustomers() {
    try {
        const response = await fetch(`${API_URL}/api/customers`);
        customersData = await response.json();
        renderCustomers(customersData);
    } catch (error) {
        console.error('Error loading customers:', error);
    }
}

function renderCustomers(customers) {
    const container = document.getElementById('customers-list');
    
    if (customers.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 40px; color: #666;">No customers yet.</p>';
        return;
    }
    
    container.innerHTML = `
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Credit Balance</th>
                    <th>Total Purchases</th>
                    <th>Member Since</th>
                </tr>
            </thead>
            <tbody>
                ${customers.map(c => `
                    <tr>
                        <td>${c.name}</td>
                        <td>${c.email || 'N/A'}</td>
                        <td>${c.phone || 'N/A'}</td>
                        <td>$${parseFloat(c.creditBalance || 0).toFixed(2)}</td>
                        <td>$${parseFloat(c.totalPurchases || 0).toFixed(2)}</td>
                        <td>${new Date(c.createdAt).toLocaleDateString()}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

async function loadTransactions() {
    try {
        const response = await fetch(`${API_URL}/api/transactions`);
        transactionsData = await response.json();
        renderTransactions(transactionsData);
    } catch (error) {
        console.error('Error loading transactions:', error);
    }
}

function renderTransactions(transactions) {
    const container = document.getElementById('transactions-list');
    
    if (transactions.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 40px; color: #666;">No transactions yet.</p>';
        return;
    }
    
    container.innerHTML = `
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Customer</th>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Credit Used</th>
                    <th>Credit Earned</th>
                    <th>Notes</th>
                </tr>
            </thead>
            <tbody>
                ${transactions.map(t => `
                    <tr>
                        <td>${new Date(t.transaction.createdAt).toLocaleString()}</td>
                        <td>${t.customer ? t.customer.name : 'N/A'}</td>
                        <td><span class="badge badge-info">${t.transaction.transactionType}</span></td>
                        <td>$${parseFloat(t.transaction.amount).toFixed(2)}</td>
                        <td>$${parseFloat(t.transaction.creditUsed || 0).toFixed(2)}</td>
                        <td>$${parseFloat(t.transaction.creditEarned || 0).toFixed(2)}</td>
                        <td>${t.transaction.notes || ''}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

async function loadMarketplaceListings() {
    try {
        const response = await fetch(`${API_URL}/api/marketplace-listings`);
        listingsData = await response.json();
        renderMarketplaceListings(listingsData);
    } catch (error) {
        console.error('Error loading marketplace listings:', error);
    }
}

function renderMarketplaceListings(listings) {
    const container = document.getElementById('listings-list');
    
    if (listings.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 40px; color: #666;">No marketplace listings yet.</p>';
        return;
    }
    
    container.innerHTML = `
        <table>
            <thead>
                <tr>
                    <th>Book</th>
                    <th>Marketplace</th>
                    <th>Price</th>
                    <th>Status</th>
                    <th>Last Synced</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${listings.map(l => `
                    <tr>
                        <td>${l.book ? l.book.title : 'N/A'}</td>
                        <td><span class="badge badge-info">${l.listing.marketplace}</span></td>
                        <td>$${parseFloat(l.listing.price || 0).toFixed(2)}</td>
                        <td><span class="badge ${l.listing.isActive ? 'badge-success' : 'badge-warning'}">${l.listing.status}</span></td>
                        <td>${l.listing.lastSynced ? new Date(l.listing.lastSynced).toLocaleDateString() : 'Never'}</td>
                        <td>
                            <button class="btn-success" onclick="syncListing(${l.listing.id})">Sync</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

function showAddBookModal() {
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <h2>Add New Book</h2>
        <form id="add-book-form" onsubmit="handleAddBook(event)">
            <div class="form-group">
                <label>ISBN</label>
                <input type="text" name="isbn" placeholder="Enter ISBN">
            </div>
            <div class="form-group">
                <label>Title *</label>
                <input type="text" name="title" required>
            </div>
            <div class="form-group">
                <label>Author</label>
                <input type="text" name="author">
            </div>
            <div class="form-group">
                <label>Publisher</label>
                <input type="text" name="publisher">
            </div>
            <div class="form-group">
                <label>Published Year</label>
                <input type="number" name="publishedYear">
            </div>
            <div class="form-group">
                <label>Genre</label>
                <select name="genre">
                    <option value="">Select Genre</option>
                    <option value="Fiction">Fiction</option>
                    <option value="Non-Fiction">Non-Fiction</option>
                    <option value="Science">Science</option>
                    <option value="History">History</option>
                    <option value="Biography">Biography</option>
                    <option value="Children">Children</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div class="form-group">
                <label>Condition</label>
                <select name="condition">
                    <option value="">Select Condition</option>
                    <option value="New">New</option>
                    <option value="Like New">Like New</option>
                    <option value="Very Good">Very Good</option>
                    <option value="Good">Good</option>
                    <option value="Acceptable">Acceptable</option>
                </select>
            </div>
            <div class="form-group">
                <label>Quantity</label>
                <input type="number" name="quantity" value="1">
            </div>
            <div class="form-group">
                <label>Our Price</label>
                <input type="number" step="0.01" name="ourPrice" placeholder="0.00">
            </div>
            <div class="form-group">
                <label>Market Value</label>
                <input type="number" step="0.01" name="marketValue" placeholder="0.00">
            </div>
            <div class="form-group">
                <label>Credit Value</label>
                <input type="number" step="0.01" name="creditValue" placeholder="0.00">
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea name="description"></textarea>
            </div>
            <button type="submit" class="btn-primary">Add Book</button>
        </form>
    `;
    document.getElementById('modal').classList.add('active');
}

async function handleAddBook(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());
    
    try {
        const response = await fetch(`${API_URL}/api/books`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            closeModal();
            loadBooks();
            alert('Book added successfully!');
        } else {
            alert('Error adding book');
        }
    } catch (error) {
        console.error('Error adding book:', error);
        alert('Error adding book');
    }
}

function showImportCustomersModal() {
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <h2>Import Customers from CSV</h2>
        <div style="margin-bottom: 20px; padding: 15px; background: #f0f9ff; border-radius: 6px; border-left: 4px solid #2563eb;">
            <h3 style="margin-top: 0; color: #1e40af;">How to import:</h3>
            <ol style="margin: 10px 0; padding-left: 20px;">
                <li>Export your Google Sheet as CSV (File → Download → CSV)</li>
                <li>Make sure your CSV has columns: <strong>name, email, phone, creditBalance</strong></li>
                <li>Upload the file below</li>
            </ol>
            <p style="margin-bottom: 0; font-size: 14px; color: #666;">
                <strong>Example CSV format:</strong><br>
                name,email,phone,creditBalance<br>
                John Doe,john@example.com,555-1234,25.50<br>
                Jane Smith,jane@example.com,555-5678,10.00
            </p>
        </div>
        <form id="import-customers-form" onsubmit="handleImportCustomers(event)">
            <div class="form-group">
                <label>CSV File *</label>
                <input type="file" id="csv-file" accept=".csv" required style="padding: 10px; border: 2px dashed #ccc; border-radius: 6px; cursor: pointer;">
            </div>
            <button type="submit" class="btn-primary">Import Customers</button>
        </form>
        <div id="import-results" style="margin-top: 20px;"></div>
    `;
    document.getElementById('modal').classList.add('active');
}

function showAddCustomerModal() {
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <h2>Add New Customer</h2>
        <form id="add-customer-form" onsubmit="handleAddCustomer(event)">
            <div class="form-group">
                <label>Name *</label>
                <input type="text" name="name" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email">
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input type="tel" name="phone">
            </div>
            <div class="form-group">
                <label>Initial Credit Balance</label>
                <input type="number" step="0.01" name="creditBalance" value="0">
            </div>
            <button type="submit" class="btn-primary">Add Customer</button>
        </form>
    `;
    document.getElementById('modal').classList.add('active');
}

async function handleAddCustomer(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());
    
    try {
        const response = await fetch(`${API_URL}/api/customers`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            closeModal();
            loadCustomers();
            alert('Customer added successfully!');
        } else {
            alert('Error adding customer');
        }
    } catch (error) {
        console.error('Error adding customer:', error);
        alert('Error adding customer');
    }
}

async function handleImportCustomers(event) {
    event.preventDefault();
    
    const fileInput = document.getElementById('csv-file');
    const file = fileInput.files[0];
    
    if (!file) {
        alert('Please select a CSV file');
        return;
    }
    
    const resultsDiv = document.getElementById('import-results');
    resultsDiv.innerHTML = '<p>Processing CSV file...</p>';
    
    try {
        const text = await file.text();
        const customers = parseCSV(text);
        
        if (customers.length === 0) {
            resultsDiv.innerHTML = '<p style="color: #ef4444;">No valid customer data found in CSV file.</p>';
            return;
        }
        
        const response = await fetch(`${API_URL}/api/customers/import`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ customers })
        });
        
        if (response.ok) {
            const results = await response.json();
            let message = `<div style="padding: 15px; background: #f0fdf4; border-radius: 6px; border-left: 4px solid #10b981;">
                <h3 style="margin-top: 0; color: #065f46;">Import Complete!</h3>
                <p><strong>Successfully imported:</strong> ${results.imported} customers</p>`;
            
            if (results.skipped > 0) {
                message += `<p><strong>Skipped:</strong> ${results.skipped} rows</p>`;
                if (results.errors.length > 0) {
                    message += '<details style="margin-top: 10px;"><summary style="cursor: pointer;">View errors</summary><ul style="margin-top: 10px;">';
                    results.errors.slice(0, 10).forEach(err => {
                        message += `<li style="font-size: 12px;">${err.error}</li>`;
                    });
                    message += '</ul></details>';
                }
            }
            
            message += '<p style="margin-bottom: 0;"><button class="btn-primary" onclick="closeModal(); loadCustomers();">Close and Refresh</button></p></div>';
            
            resultsDiv.innerHTML = message;
        } else {
            resultsDiv.innerHTML = '<p style="color: #ef4444;">Error importing customers. Please try again.</p>';
        }
    } catch (error) {
        console.error('Error importing customers:', error);
        resultsDiv.innerHTML = `<p style="color: #ef4444;">Error: ${error.message}</p>`;
    }
}

function parseCSV(text) {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length < 2) return [];
    
    const parseCSVLine = (line) => {
        const result = [];
        let current = '';
        let inQuotes = false;
        
        for (let i = 0; i < line.length; i++) {
            const char = line[i];
            
            if (char === '"') {
                inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
                result.push(current.trim());
                current = '';
            } else {
                current += char;
            }
        }
        result.push(current.trim());
        return result;
    };
    
    const headerLine = parseCSVLine(lines[0]);
    const headers = headerLine.map(h => h.trim().toLowerCase().replace(/[^a-z0-9]/g, ''));
    const customers = [];
    
    for (let i = 1; i < lines.length; i++) {
        const values = parseCSVLine(lines[i]);
        const customer = {};
        
        headers.forEach((header, index) => {
            const value = values[index]?.replace(/^"|"$/g, '').trim();
            if (value) {
                if (header === 'name') {
                    customer.name = value;
                } else if (header === 'email') {
                    customer.email = value;
                } else if (header === 'phone' || header === 'phonenumber') {
                    customer.phone = value;
                } else if (header === 'creditbalance' || header === 'credit' || header === 'storecredit' || header === 'balance') {
                    const numValue = parseFloat(value.replace(/[^0-9.-]/g, ''));
                    if (!isNaN(numValue)) {
                        customer.creditBalance = numValue.toString();
                    }
                }
            }
        });
        
        if (customer.name) {
            customers.push(customer);
        }
    }
    
    return customers;
}

function showAddTransactionModal() {
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <h2>New Transaction</h2>
        <form id="add-transaction-form" onsubmit="handleAddTransaction(event)">
            <div class="form-group">
                <label>Transaction Type *</label>
                <select name="transactionType" required>
                    <option value="sale">Sale</option>
                    <option value="purchase">Purchase</option>
                    <option value="trade-in">Trade-In</option>
                    <option value="credit-adjustment">Credit Adjustment</option>
                </select>
            </div>
            <div class="form-group">
                <label>Amount *</label>
                <input type="number" step="0.01" name="amount" required>
            </div>
            <div class="form-group">
                <label>Credit Used</label>
                <input type="number" step="0.01" name="creditUsed" value="0">
            </div>
            <div class="form-group">
                <label>Credit Earned</label>
                <input type="number" step="0.01" name="creditEarned" value="0">
            </div>
            <div class="form-group">
                <label>Notes</label>
                <textarea name="notes"></textarea>
            </div>
            <button type="submit" class="btn-primary">Create Transaction</button>
        </form>
    `;
    document.getElementById('modal').classList.add('active');
}

async function handleAddTransaction(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());
    
    try {
        const response = await fetch(`${API_URL}/api/transactions`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            closeModal();
            loadTransactions();
            alert('Transaction created successfully!');
        } else {
            alert('Error creating transaction');
        }
    } catch (error) {
        console.error('Error creating transaction:', error);
        alert('Error creating transaction');
    }
}

function showAddListingModal() {
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <h2>Add Marketplace Listing</h2>
        <p style="margin-bottom: 20px;">Note: Integration features are ready for Pango, Shopify, and Amazon marketplace connections.</p>
        <form id="add-listing-form" onsubmit="handleAddListing(event)">
            <div class="form-group">
                <label>Marketplace *</label>
                <select name="marketplace" required>
                    <option value="Pango">Pango</option>
                    <option value="Shopify">Shopify (Coming Soon)</option>
                    <option value="Amazon">Amazon (Coming Soon)</option>
                </select>
            </div>
            <div class="form-group">
                <label>Listing ID</label>
                <input type="text" name="listingId" placeholder="External marketplace ID">
            </div>
            <div class="form-group">
                <label>Price *</label>
                <input type="number" step="0.01" name="price" required>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="active">Active</option>
                    <option value="pending">Pending</option>
                    <option value="sold">Sold</option>
                </select>
            </div>
            <button type="submit" class="btn-primary">Add Listing</button>
        </form>
    `;
    document.getElementById('modal').classList.add('active');
}

async function handleAddListing(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());
    data.isActive = data.status === 'active';
    
    try {
        const response = await fetch(`${API_URL}/api/marketplace-listings`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            closeModal();
            loadMarketplaceListings();
            alert('Listing added successfully!');
        } else {
            alert('Error adding listing');
        }
    } catch (error) {
        console.error('Error adding listing:', error);
        alert('Error adding listing');
    }
}

async function deleteBook(id) {
    if (!confirm('Are you sure you want to delete this book?')) return;
    
    try {
        const response = await fetch(`${API_URL}/api/books/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            loadBooks();
            alert('Book deleted successfully!');
        } else {
            alert('Error deleting book');
        }
    } catch (error) {
        console.error('Error deleting book:', error);
        alert('Error deleting book');
    }
}

function editBook(id) {
    alert('Edit functionality coming soon! For now, you can delete and re-add the book.');
}

function syncListing(id) {
    alert('Marketplace sync functionality is ready to be connected to your Pango, Shopify, or Amazon account!');
}

function closeModal() {
    document.getElementById('modal').classList.remove('active');
}

window.onclick = function(event) {
    const modal = document.getElementById('modal');
    if (event.target === modal) {
        closeModal();
    }
}
