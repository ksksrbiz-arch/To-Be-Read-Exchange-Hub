# Book Exchange Management System

## Overview
A comprehensive web application for managing a book exchange business with inventory tracking, customer management, credit system, and marketplace integration capabilities.

## Project Goals
- Organize and categorize book inventory
- Track current market values and pricing
- Manage customer credits for book exchanges
- Integrate with multiple marketplaces (Pango, Shopify, Amazon)
- Provide productivity tools for higher profits

## Recent Changes
**October 25, 2025** - Initial project setup
- Created PostgreSQL database with comprehensive schema
- Built RESTful API backend with Express.js
- Developed responsive frontend dashboard
- Implemented core features:
  - Book inventory management with ISBN support
  - Pricing and market value tracking
  - Customer management with credit balance system
  - Transaction processing (sales, purchases, trade-ins)
  - Marketplace listing framework

## Technology Stack
- **Backend**: Node.js, Express.js
- **Database**: PostgreSQL (Neon) with Drizzle ORM
- **Frontend**: HTML, CSS, JavaScript (vanilla)
- **APIs**: RESTful architecture

## Database Schema
The system uses the following main tables:
- `books` - Book catalog with ISBN, title, author, genre, condition
- `inventory` - Stock quantities and locations
- `pricing` - Price tracking (our price, market value, credit value, cost basis)
- `customers` - Customer profiles with credit balance tracking
- `transactions` - All business transactions (sales, purchases, trade-ins)
- `transaction_items` - Line items for each transaction
- `marketplace_listings` - Multi-channel marketplace integration

## Key Features

### Book Management
- Add, edit, delete books with full details
- ISBN lookup support
- Genre and condition categorization
- Image support
- Real-time search and filtering

### Inventory Tracking
- Quantity management
- Location tracking
- Status monitoring (available, sold, reserved)
- Automatic updates from transactions

### Pricing System
- Our selling price
- Market value tracking
- Credit value for trade-ins
- Cost basis for profit calculations
- Price update timestamps

### Customer & Credit System
- Customer profiles with contact information
- Credit balance tracking
- Purchase history
- Automatic credit calculations for trade-ins
- Credit usage in transactions

### Transaction Processing
- Multiple transaction types: sales, purchases, trade-ins, credit adjustments
- Line item support
- Automatic inventory adjustments
- Credit earning and spending
- Transaction history

### Marketplace Integration Framework
Ready for integration with:
- **Pango** (current platform) - Sync existing listings
- **Shopify** - Create custom storefront
- **Amazon** - Access large marketplace
- **Expandable** to Temu, Alibaba, and other platforms

## API Endpoints

### Books
- `GET /api/books` - List all books with filters
- `GET /api/books/:id` - Get book details
- `POST /api/books` - Add new book
- `PUT /api/books/:id` - Update book
- `DELETE /api/books/:id` - Delete book

### Inventory & Pricing
- `PUT /api/inventory/:id` - Update inventory
- `PUT /api/pricing/:bookId` - Update pricing

### Customers
- `GET /api/customers` - List all customers
- `POST /api/customers` - Add new customer

### Transactions
- `GET /api/transactions` - List all transactions
- `POST /api/transactions` - Create transaction

### Marketplace
- `GET /api/marketplace-listings` - List all listings
- `POST /api/marketplace-listings` - Create listing
- `PUT /api/marketplace-listings/:id` - Update listing

### Stats
- `GET /api/stats` - Dashboard statistics

## Development

### Running the Application
The server runs on port 5000 and serves both the API and frontend.

### Database Migrations
```bash
npm run db:push
```

### Environment Variables
- `DATABASE_URL` - PostgreSQL connection string (auto-configured)
- `PGHOST`, `PGPORT`, `PGUSER`, `PGPASSWORD`, `PGDATABASE` - Database credentials

## CSV Import Feature
**Added: October 25, 2025**

The system now includes a customer import feature for migrating existing data from Google Sheets:

### How to Import Customers
1. Open your Google Sheet with customer data
2. Export as CSV: File → Download → Comma Separated Values (.csv)
3. In the app, go to Customers → Import from CSV
4. Upload your CSV file
5. Review import results (successful imports, skipped rows, errors)

### Supported CSV Formats
The importer handles flexible column naming:
- **Name**: name, Name, NAME (required)
- **Email**: email, Email, EMAIL
- **Phone**: phone, Phone, phone number, Phone Number
- **Credit Balance**: creditBalance, credit, storeCredit, balance, Credit Balance, Store Credit

The parser handles:
- Quoted values with commas
- Currency symbols in credit amounts
- Various header formatting styles
- Empty/missing values

### Import Results
After import, you'll see:
- Number of successfully imported customers
- Number of skipped rows (with reasons)
- Detailed error messages for failed imports

### CSV Format Notes
For best results, keep your Google Sheets data simple:
- Avoid multi-line text in cells (use simple one-line entries)
- Use standard formats for phone numbers and emails
- Credit balances can include currency symbols ($25.50 or 25.50 both work)

**Future Enhancement**: For complex CSV files with multi-line fields or embedded quotes, a library like PapaParse could be integrated for more robust parsing.

## Next Steps & Future Enhancements
1. **Marketplace API Integration** - Connect to Pango, Shopify, and Amazon APIs
2. **Automated Price Updates** - Fetch current market values from online sources
3. **Barcode Scanner** - Quick book entry via ISBN scanning
4. **Reporting Dashboard** - Sales analytics and profit tracking
5. **Email Notifications** - Customer transaction receipts
6. **Mobile Responsive** - Optimize for mobile devices
7. **Bulk Book Import** - CSV upload for large book inventories
8. **Advanced Search** - Full-text search across all fields
9. **User Authentication** - Multi-user access with roles

## Business Model
The system supports a book exchange model where:
- Customers can sell books for store credit
- Credits can be used for purchases
- Flexible pricing based on condition and market value
- Multi-channel selling maximizes reach and profit

## Architecture Notes
- Single-page application with dynamic content loading
- RESTful API design for future mobile app integration
- Normalized database schema for data integrity
- Extensible marketplace integration framework
- Real-time inventory tracking prevents overselling
